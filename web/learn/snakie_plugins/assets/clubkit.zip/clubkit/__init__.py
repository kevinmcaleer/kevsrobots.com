"""ClubKit: a Snakie plugin for our robot club."""

import re

from snakie import Context, block, diagnostic, edit, fix, message, plugin, status

HEADER = "# Robot Club\n"
PIN_USE = re.compile(r"Pin\(\s*(\d+)")
LONG_SLEEP = re.compile(r"\bsleep\(\s*(\d{3,})\s*\)")
OFF_HEADER = {23: "the power supply mode", 24: "USB power sensing", 29: "the VSYS voltage reading"}


# ---------- Commands ----------

@plugin.command("clubkit.header", "Add club header")
def add_header(ctx: Context):
    """Put the club's header comment at the top of the file."""
    if ctx.file.content.startswith(HEADER):
        return message("info", "This file already has the club header.")
    return [
        edit(HEADER + f"# File: {ctx.file.name}\n\n" + ctx.file.content),
        message("info", f"Added the club header to {ctx.file.name}."),
    ]


@plugin.command("clubkit.pins", "List the pins")
def list_pins(ctx: Context):
    """Report every GPIO pin the program uses."""
    pins = sorted({int(n) for n in PIN_USE.findall(ctx.file.content)})
    if not pins:
        return message("warning", "No pins found. Is this the right file?")
    names = ", ".join(f"GP{n}" for n in pins)
    return [
        message("info", f"{ctx.file.name} uses {len(pins)} pin(s): {names}"),
        status(f"Pins: {names}", tooltip="From ClubKit"),
    ]


# ---------- Linter ----------

@plugin.linter("club-rules")
def club_rules(ctx: Context):
    """Squiggle the mistakes our club makes most often."""
    found = []
    for number, line in enumerate(ctx.file.content.splitlines(), start=1):
        code = line.split("#")[0]

        match = LONG_SLEEP.search(code)
        if match:
            found.append(diagnostic(
                number,
                f"sleep({match.group(1)}) waits {match.group(1)} seconds. Did you mean milliseconds?",
                severity="warning",
                column=match.start() + 1,
                end_column=match.end() + 1,
                source="clubkit",
                fixes=[fix(f"Change to sleep_ms({match.group(1)})", f"sleep_ms({match.group(1)})")],
            ))

        for match in PIN_USE.finditer(code):
            pin = int(match.group(1))
            if pin in OFF_HEADER:
                found.append(diagnostic(
                    number,
                    f"GP{pin} is used by the Pico for {OFF_HEADER[pin]}. Pick another pin.",
                    severity="error",
                    column=match.start(1) + 1,
                    end_column=match.end(1) + 1,
                    source="clubkit",
                ))
    return found


# ---------- Blocks ----------

@plugin.blocks("ClubKit")
def club_blocks():
    """Blocks for the club's robot."""
    imports = [{"module": "clubbot"}]
    return [
        block("forward", "drive forward %1 cm", "clubbot.forward({CM})\n",
              args=[{"name": "CM", "kind": "number", "default": 20}],
              imports=imports, tooltip="Drive forward in a straight line."),
        block("turn", "turn %1 by %2 degrees", "clubbot.turn({DIR} * {DEG})\n",
              args=[{"name": "DIR", "kind": "choice", "options": [["right", "1"], ["left", "-1"]]},
                    {"name": "DEG", "kind": "number", "default": 90}],
              imports=imports, tooltip="Turn on the spot."),
        block("stop", "stop the motors", "clubbot.stop()\n",
              imports=imports, tooltip="Stop both motors."),
        block("distance", "distance ahead in cm", "clubbot.distance()",
              shape="value", output="Number",
              imports=imports, tooltip="How far away the nearest thing is."),
    ]
