# ClubKit

A Snakie plugin for a robot club, built in the kevsrobots.com course
"Extend Snakie with Python Plugins".

- Add club header: stamps the club header on the open file
- List the pins: shows every GPIO pin the program uses
- Warns about sleep() calls that look like milliseconds, with a quick fix
- Flags pins that are not on the Raspberry Pi Pico's header
- Adds a ClubKit drawer of blocks for the club robot

Needs the Snakie desktop app and Python 3.

Install: copy this folder into .snakie/plugins in your home folder,
then click Reload in the Plugins panel.
