def make_screen():
    """A real SSD1306 if one is connected, otherwise the simulated screen."""
    try:
        from machine import Pin, I2C
        from ssd1306 import SSD1306_I2C
        return SSD1306_I2C(128, 64, I2C(0, sda=Pin(0), scl=Pin(1)))
    except Exception as problem:
        print("No OLED found (" + str(problem) + "), using the Display instrument")
        from simscreen import SimScreen
        return SimScreen()
