"""Read Snakie .spr sprite files on the board."""

import struct
import framebuf


class Spr:
    """A .spr animation, read one frame at a time from the board's files."""

    def __init__(self, path):
        self.f = open(path, "rb")
        header = struct.unpack("<4sBBBBHHHH", self.f.read(16))
        magic, version, flags, fmt, _, w, h, count, ms = header
        if magic != b"SNKS":
            raise ValueError("not a Snakie sprite")
        self.width, self.height, self.count, self.ms = w, h, count, ms
        self.size = (w + 7) // 8 * h
        self.buf = bytearray(self.size)
        self.fb = framebuf.FrameBuffer(self.buf, w, h, framebuf.MONO_HLSB)

    def frame(self, i):
        self.f.seek(16 + i * self.size)
        self.f.readinto(self.buf)
        return self.fb
