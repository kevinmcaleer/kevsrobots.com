import time
import random
from machine import ADC
from simscreen import SimScreen
import eye

OPEN, HALF, CLOSED, LEFT, RIGHT = 0, 1, 2, 3, 4
SLEEPY_BELOW = 20000

screen = SimScreen()
light = ADC(26)


def draw_big(i, left, top, scale):
    for y in range(eye.HEIGHT):
        for x in range(eye.WIDTH):
            if eye.pixel(i, x, y):
                screen.fill_rect(left + x * scale, top + y * scale, scale, scale, 1)


def face(i, message=""):
    screen.fill(0)
    draw_big(i, 12, 0, 3)
    draw_big(i, 68, 0, 3)
    screen.text(message, 0, 56, 1)
    screen.show()


def blink():
    for i in [HALF, CLOSED, HALF, OPEN]:
        face(i)


while True:
    level = light.read_u16()
    if level < SLEEPY_BELOW:
        face(HALF, "sleepy...")
        time.sleep(0.6)
        continue
    face(OPEN, "light " + str(level))
    time.sleep(random.uniform(0.3, 0.9))
    choice = random.randint(0, 3)
    if choice == 0:
        face(LEFT)
        time.sleep(0.4)
    elif choice == 1:
        face(RIGHT)
        time.sleep(0.4)
    else:
        blink()
