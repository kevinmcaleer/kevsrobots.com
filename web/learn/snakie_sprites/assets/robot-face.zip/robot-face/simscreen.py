"""A pretend 128x64 OLED that shows up in Snakie's Display instrument."""

import binascii
import framebuf
import instruments as inst


class SimScreen(framebuf.FrameBuffer):
    def __init__(self, width=128, height=64):
        self.width = width
        self.height = height
        self.buffer = bytearray(width * height // 8)
        super().__init__(self.buffer, width, height, framebuf.MONO_HLSB)

    def show(self):
        data = binascii.b2a_base64(self.buffer).decode().strip()
        inst.screen_fb(data, self.width, self.height)
