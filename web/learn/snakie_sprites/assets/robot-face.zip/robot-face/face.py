from simscreen import SimScreen
import eye

screen = SimScreen()


def face(i):
    screen.fill(0)
    screen.blit(eye.frame(i), 40, 24)
    screen.blit(eye.frame(i), 72, 24)
    screen.show()


face(0)
