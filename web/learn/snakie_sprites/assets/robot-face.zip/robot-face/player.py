import time
from simscreen import SimScreen
from spr import Spr

screen = SimScreen()
eye = Spr("eye.spr")
print(eye.width, "x", eye.height, "-", eye.count, "frames,", eye.ms, "ms each")

for loop in range(3):
    for i in range(eye.count):
        screen.fill(0)
        screen.blit(eye.frame(i), 56, 24)
        screen.show()
        time.sleep_ms(eye.ms)
print("done")
