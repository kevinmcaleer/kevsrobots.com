import time
from simscreen import SimScreen
import eye

OPEN, HALF, CLOSED, LEFT, RIGHT = 0, 1, 2, 3, 4

screen = SimScreen()


def draw_big(i, left, top, scale):
    for y in range(eye.HEIGHT):
        for x in range(eye.WIDTH):
            if eye.pixel(i, x, y):
                screen.fill_rect(left + x * scale, top + y * scale, scale, scale, 1)


def face(i, shift=0):
    screen.fill(0)
    draw_big(i, 12 + shift, 8, 3)
    draw_big(i, 68 + shift, 8, 3)
    screen.show()


face(OPEN)
time.sleep(1)
for i in [HALF, CLOSED, HALF, OPEN]:
    face(i)
time.sleep(0.5)
for shift in [0, -4, -8, -4, 0, 4, 8, 4, 0]:
    face(LEFT if shift < 0 else RIGHT if shift > 0 else OPEN, shift)
print("done")
