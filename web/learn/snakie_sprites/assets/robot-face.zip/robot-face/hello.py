from simscreen import SimScreen

screen = SimScreen()

screen.fill(0)
screen.rect(0, 0, 128, 64, 1)
screen.text("Hello, robot!", 12, 20, 1)
screen.hline(12, 32, 104, 1)
screen.show()
