import time
import random
from simscreen import SimScreen
import eye

OPEN, HALF, CLOSED, LEFT, RIGHT = 0, 1, 2, 3, 4

screen = SimScreen()


def face(i):
    screen.fill(0)
    screen.blit(eye.frame(i), 40, 24)
    screen.blit(eye.frame(i), 72, 24)
    screen.show()


def blink():
    for i in [HALF, CLOSED, HALF, OPEN]:
        face(i)
        time.sleep(0.06)


def glance(direction):
    face(direction)
    time.sleep(0.5)
    face(OPEN)


face(OPEN)
while True:
    time.sleep(random.uniform(0.4, 1.2))
    choice = random.randint(0, 3)
    if choice == 0:
        glance(LEFT)
    elif choice == 1:
        glance(RIGHT)
    else:
        blink()
